package com.example.lembrafacil

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lembrafacil.database.UsuarioDAO
import com.example.lembrafacil.model.Usuario

class NovoUsuario : AppCompatActivity() {

    private lateinit var editTextNome: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var editTextCPF: EditText
    private lateinit var editTextSenha: EditText
    private lateinit var editTextDataNasc: EditText
    private lateinit var checkBoxNivel: CheckBox
    private lateinit var btnSalvar: Button
    private lateinit var btnVoltar: Button // Adicionada

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_novo_usuario)

        editTextNome = findViewById(R.id.textViewNome)
        editTextEmail = findViewById(R.id.textViewEmail)
        editTextCPF = findViewById(R.id.textViewCPF)
        editTextSenha = findViewById(R.id.textViewSenha)
        editTextDataNasc = findViewById(R.id.textViewDataNasc)
        checkBoxNivel = findViewById(R.id.textViewNivel)
        btnSalvar = findViewById(R.id.btnSalvar)
        btnVoltar = findViewById(R.id.Voltar1)

        btnSalvar.setOnClickListener {
            val nome = editTextNome.text.toString()
            val email = editTextEmail.text.toString()
            val cpf = editTextCPF.text.toString()
            val senha = editTextSenha.text.toString()
            val dataNasc = editTextDataNasc.text.toString()
            val nivelAcesso = if (checkBoxNivel.isChecked) 1 else 0

            val novoUsuario = Usuario(0, nome, email, cpf, senha, dataNasc, nivelAcesso)

            val usuarioDAO = UsuarioDAO(this)
            usuarioDAO.insertUsuario(novoUsuario)

            Toast.makeText(this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
            finish()
        }

        btnVoltar.setOnClickListener {
            finish() // Fecha a activity e volta para a anterior
        }
    }
}
