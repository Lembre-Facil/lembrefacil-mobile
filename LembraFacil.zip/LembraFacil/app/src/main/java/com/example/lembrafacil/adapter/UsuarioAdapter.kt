package com.example.lembrafacil.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.example.lembrafacil.R
import com.example.lembrafacil.model.Usuario

class UsuarioAdapter(
    private val context: Context,
    private var usuarios: MutableList<Usuario>
) : BaseAdapter() {

    override fun getCount(): Int = usuarios.size

    override fun getItem(position: Int): Any = usuarios[position]

    override fun getItemId(position: Int): Long = usuarios[position].id

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.activity_item_usuario, parent, false)

        val usuario = usuarios[position]

        val textViewNome = view.findViewById<TextView>(R.id.textViewNome)
        val textViewEmail = view.findViewById<TextView>(R.id.textViewEmail)
        val textViewCPF = view.findViewById<TextView>(R.id.textViewCPF)
        val textViewDataNasc = view.findViewById<TextView>(R.id.textViewDataNasc)
        val textViewNivel = view.findViewById<TextView>(R.id.textViewNivel)

        textViewNome.text = usuario.nome
        textViewEmail.text = usuario.email
        textViewCPF.text = usuario.cpf
        textViewDataNasc.text = usuario.dataNasc
        textViewNivel.text = if (usuario.nivelAcesso == 1) "Admin" else "Usuário"

        return view
    }

    fun atualizarUsuarios(novosUsuarios: List<Usuario>) {
        usuarios.clear()
        usuarios.addAll(novosUsuarios)
        notifyDataSetChanged()
    }
}