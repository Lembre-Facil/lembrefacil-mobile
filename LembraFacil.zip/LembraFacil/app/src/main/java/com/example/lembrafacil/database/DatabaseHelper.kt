package com.example.lembrafacil.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "lembrafacil.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Script para criar tabela Usuario
        val scriptSQL_createTable_Usuario = """
            CREATE TABLE Usuario (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome VARCHAR(100) NOT NULL,
                email VARCHAR(50) NOT NULL UNIQUE,
                cpf VARCHAR(11),
                senha VARCHAR(60),
                dataNasc DATE,
                nivelAcesso INTEGER
            )
        """.trimIndent()

        db.execSQL(scriptSQL_createTable_Usuario)

        // Inserir usuário administrador padrão
        val scriptSQL_insert_Admin = """
            INSERT INTO Usuario (nome, email, cpf, senha, dataNasc, nivelAcesso)
            VALUES ('Administrador', 'admin@lembrafacil.com', '00000000000', 'admin', '2000-01-01', 1)
        """.trimIndent()

        db.execSQL(scriptSQL_insert_Admin)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Caso a versão mude, exclui a tabela e recria
        db.execSQL("DROP TABLE IF EXISTS Usuario")
        onCreate(db)
    }
}
