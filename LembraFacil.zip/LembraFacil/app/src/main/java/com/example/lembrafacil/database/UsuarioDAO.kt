package com.example.lembrafacil.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import com.example.lembrafacil.model.Usuario
import org.mindrot.jbcrypt.BCrypt

class UsuarioDAO(context: Context) {

    private val dbHelper = DatabaseHelper(context)

    /**
     * Insere um novo usuário no banco de dados.
     */
    fun insertUsuario(usuario: Usuario) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("nome", usuario.nome)
            put("email", usuario.email)
            put("cpf", usuario.cpf)
            put("senha", BCrypt.hashpw(usuario.senha, BCrypt.gensalt()))  // Criptografa a senha!
            put("dataNasc", usuario.dataNasc)
            put("nivelAcesso", usuario.nivelAcesso)
        }
        db.insert("Usuario", null, values)
        db.close()
    }

    /**
     * Deleta um usuário pelo ID.
     */
    fun deletarUsuario(id: Long): Int {
        val db = dbHelper.writableDatabase
        val result = db.delete("Usuario", "id = ?", arrayOf(id.toString()))
        db.close()
        return result
    }

    /**
     * Atualiza um usuário.
     */
    fun atualizarUsuario(usuario: Usuario): Int {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("nome", usuario.nome)
            put("email", usuario.email)
            put("cpf", usuario.cpf)
            put("senha", BCrypt.hashpw(usuario.senha, BCrypt.gensalt()))  // Atualiza criptografada
            put("dataNasc", usuario.dataNasc)
            put("nivelAcesso", usuario.nivelAcesso)
        }
        val result = db.update("Usuario", values, "id = ?", arrayOf(usuario.id.toString()))
        db.close()
        return result
    }

    /**
     * Busca usuário por e-mail.
     */
    fun procuraUsuarioPorEmail(email: String): Usuario? {
        val db = dbHelper.readableDatabase
        var usuario: Usuario? = null
        val cursor = db.query(
            "Usuario",
            null,
            "email = ?",
            arrayOf(email),
            null,
            null,
            null
        )
        cursor.use {
            if (it.moveToFirst()) {
                usuario = criarUsuario(it)
            }
        }
        db.close()
        return usuario
    }

    /**
     * Autentica o usuário pelo e-mail e senha.
     */
    fun procuraUsuarioPorNomeESenha(email: String, senha: String): Usuario? {
        val db = dbHelper.readableDatabase
        var usuario: Usuario? = null
        val cursor = db.query(
            "Usuario",
            null,
            "email = ?",
            arrayOf(email),
            null,
            null,
            null
        )
        cursor.use {
            if (it.moveToFirst()) {
                val storedHash = it.getString(it.getColumnIndexOrThrow("senha"))
                if (BCrypt.checkpw(senha, storedHash)) {
                    usuario = criarUsuario(it)
                }
            }
        }
        db.close()
        return usuario
    }

    /**
     * Lista usuários filtrando pelo termo de busca.
     */
    fun criaListaDeUsuarios(valor: String): List<Usuario> {
        val db = dbHelper.readableDatabase
        val usuarios = mutableListOf<Usuario>()
        val cursor = db.query(
            "Usuario",
            null,
            "nome LIKE ? OR email LIKE ? OR cpf LIKE ?",
            arrayOf("%$valor%", "%$valor%", "%$valor%"),
            null,
            null,
            null
        )
        cursor.use {
            while (it.moveToNext()) {
                usuarios.add(criarUsuario(it))
            }
        }
        db.close()
        return usuarios
    }

    /**
     * Cria objeto Usuario a partir do cursor.
     */
    private fun criarUsuario(cursor: Cursor): Usuario {
        return Usuario(
            id = cursor.getLong(cursor.getColumnIndexOrThrow("id")),
            nome = cursor.getString(cursor.getColumnIndexOrThrow("nome")),
            email = cursor.getString(cursor.getColumnIndexOrThrow("email")),
            cpf = cursor.getString(cursor.getColumnIndexOrThrow("cpf")),
            senha = cursor.getString(cursor.getColumnIndexOrThrow("senha")),
            dataNasc = cursor.getString(cursor.getColumnIndexOrThrow("dataNasc")),
            nivelAcesso = cursor.getInt(cursor.getColumnIndexOrThrow("nivelAcesso"))
        )
    }
}
