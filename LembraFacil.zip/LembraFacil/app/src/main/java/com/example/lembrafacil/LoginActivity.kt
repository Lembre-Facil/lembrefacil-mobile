package com.example.lembrafacil

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lembrafacil.database.UsuarioDAO

class LoginActivity : AppCompatActivity() {

    private lateinit var txtEmail: EditText
    private lateinit var txtSenha: EditText
    private lateinit var btnEntrar: Button
    private lateinit var btnNovoUsuario: Button
    private lateinit var btnVoltar: Button
    private lateinit var mensagemErro: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        txtEmail = findViewById(R.id.txtEmail)
        txtSenha = findViewById(R.id.txtSenha)
        btnEntrar = findViewById(R.id.btnEntrar)
        btnNovoUsuario = findViewById(R.id.btnNovoUser)
        btnVoltar = findViewById(R.id.btnVoltar)
        mensagemErro = findViewById(R.id.mensagemErro)

        btnEntrar.setOnClickListener {
            val email = txtEmail.text.toString()
            val senha = txtSenha.text.toString()

            val usuarioDAO = UsuarioDAO(this)
            val usuario = usuarioDAO.procuraUsuarioPorNomeESenha(email, senha)


            if (usuario != null) {
                startActivity(Intent(this, ListarUsuario::class.java))
                finish()
            } else {
                mensagemErro.text = "Usuário ou senha inválidos!"
            }
        }

        btnNovoUsuario.setOnClickListener {
            startActivity(Intent(this, NovoUsuario::class.java))
        }

        btnVoltar.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}