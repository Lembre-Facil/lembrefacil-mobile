package com.example.lembrafacil

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.lembrafacil.adapter.UsuarioAdapter
import com.example.lembrafacil.database.UsuarioDAO


class ListarUsuario : AppCompatActivity() {

    private lateinit var editTextProcurar: EditText
    private lateinit var btnProcurar: Button
    private lateinit var listViewUsuarios: ListView
    private lateinit var usuarioAdapter: UsuarioAdapter
    private lateinit var btnVoltar: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listar_usuario)

        editTextProcurar = findViewById(R.id.editTextProcurar)
        btnProcurar = findViewById(R.id.btnProcurar)
        listViewUsuarios = findViewById(R.id.listViewUsuarios)
        btnVoltar = findViewById(R.id.vol)

        btnProcurar.setOnClickListener {
            val termoBusca = editTextProcurar.text.toString()

            val usuarioDAO = UsuarioDAO(this)
            val listaUsuarios = usuarioDAO.criaListaDeUsuarios(termoBusca)

            usuarioAdapter = UsuarioAdapter(this, listaUsuarios.toMutableList())
            listViewUsuarios.adapter = usuarioAdapter
        }
        btnVoltar.setOnClickListener {
            finish()
        }
    }
}